import './Header.css'

export const Header  = () => {
  return(
    <div className='header'>
      Dio Bank
    </div>
  )
}
