export const login = (): void => {
    alert('Bem vinda!')
}
